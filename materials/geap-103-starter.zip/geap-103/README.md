# GEAP 103: Basic Computer Skills

This is your course folder. Keep your course work here. Keep passwords, identification documents, grades, and private chat or recording data out of GitHub.

## Folder structure

```
geap-103/
  week-01/ through week-14/   — weekly work (put each week's files in the right folder)
  week-02/shared-practice/     — common Week 2 practice files and tasks
  goal-document/               — your Goal Document (one file, updated weekly)
  decision-logs/               — decision-log.md: one continuing Markdown log
  portfolio/                   — files for your portfolio
  session-reviews/             — your end-of-class AI conversations
```

**About these files:**
- `.gitkeep` files (small invisible files that keep empty folders from disappearing — leave them)
- `.md` files are Markdown: ordinary text with headings. Open them in VS Code or another plain-text editor. Your Decision Log uses this format.

## Naming convention

- Lowercase, hyphens, no spaces: `goal-document-yourname.docx`, not `Goal Document YourName.docx`
- This matters because some tools can't handle spaces in file names. Lowercase with hyphens works everywhere.

## Getting started

1. Move this whole `geap-103` folder into your OneDrive
2. Open the goal document template (`goal-document/goal-document-template.docx`) and rename it with your name (e.g., `goal-document-priya.docx`)
3. If your instructor tells you to use the shared Week 2 tasks, open `week-02/shared-practice/TASKS.md`
4. You're ready for class

If you're confused about anything, ask your instructor or ask AI: "What is this folder for?"

## Decision Log

In Week 2, open `decision-logs/decision-log.md`. Add dated, numbered entries to that one file. From Week 3, keep it in your private `geap-103-portfolio` repository and invite your teacher. Do not upload student work to the public course-materials repository.

At the Week 4, 8, and 11 collection points, submit a permanent link to the committed log in Blackboard. If GitHub is unavailable, keep the same file locally or in OneDrive and upload it to Blackboard. Assessment feedback and grades stay in Blackboard.

See the [Decision Log workflow](https://github.com/BrettRey/geap-103/blob/main/onboarding/decision-logs.md).
