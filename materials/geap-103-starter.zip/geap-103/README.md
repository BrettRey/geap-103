# GEAP 103: Basic Computer Skills

This is your course folder. Everything you make this semester goes here.

## Folder structure

```
geap-103/
  week-01/ through week-14/   — weekly work (put each week's files in the right folder)
  goal-document/               — your Goal Document (one file, updated weekly)
  decision-logs/               — your Decision Log entries
  portfolio/                   — files for your portfolio
  session-reviews/             — your end-of-class AI conversations
```

**Files you can ignore:**
- `.gitkeep` files (small invisible files that keep empty folders from disappearing — leave them)
- `.md` files are plain text files. You can open them in any text editor (Notepad, TextEdit) or just leave them

## Naming convention

- Lowercase, hyphens, no spaces: `goal-document-yourname.docx`, not `Goal Document YourName.docx`
- This matters because some tools can't handle spaces in file names. Lowercase with hyphens works everywhere.

## Getting started

1. Move this whole `geap-103` folder into your OneDrive
2. Open the goal document template (`goal-document/goal-document-template.docx`) and rename it with your name (e.g., `goal-document-priya.docx`)
3. You're ready for class

If you're confused about anything, ask your instructor or ask AI: "What is this folder for?"
